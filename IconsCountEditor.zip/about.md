# IconsCountEditor by user95401

change gmd icons count via config file

finded by [Guschin](https://github.com/zGuschin/IconPatch)

## <co>Converted for Geode</c>
---

<cr>This is traditional mod that uses minhook, gd.h, cocos-haders!

BUT! In general, this mod works, and IN MOST CASES IT is COMPATIBLE.
- Made with curly-eureka</c>
