# v1.1.0

 * In-game values editor
 * Bug fixes

# v1.0.0

 * Initial release
