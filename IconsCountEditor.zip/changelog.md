# v1.2.0

 * Auto calculation icons count by loaded textures
 * Bug fixes?

# v1.1.0

 * In-game values editor
 * Bug fixes

# v1.0.0

 * Initial release
